#FirstPython
print('a',"a")
ADVXDSV_L_A_B_C_PRINT_L_ = """print("Hellowww,Komali")
print(6+2-3)
l=['a','b','c']
print(l[2])
"""
var="helo da 2d tame"
print("comali " +var+ " 3232")
x=y=z=' i am a super star ' #Multi variable assignments
x='concat ds'
y=x.split(" ")
print(y[1])
"""print(x[3]) #String as array
print(x[-3:]) #String as array
print(x.strip())
print(x.split(" "))
print('a' in x)
for a in x:
    print(a)"""
