x=y=z='samPle String OperatioNs' #Multi variable assignments
da='concat'
print(x[3]) #String as array
print(x[0:3]) #Slicing - similar to substr
print(x[2:]) #slicing - but print all from particular point
print(x[-3:]) #slicing from back
print(x.upper()) #convert to upper case
print(x.strip()) #similar to trim - trimout spaces
print(x.replace(" ","")) #Replace command
print(x.split(" ")) #Split string based on input & change as array
print(x+" "+da) #conactenation of string
f=x.split(" ")
print(f[0])

#Multi line assignments
X='''abc
sds
sfs'''
print(X)
# usage of IN
ve='abc'
print('String' in x)
#Forloop syntax
for a in ve:
 print(a)
 


