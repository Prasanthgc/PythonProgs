x=25
y=20
p=x*2
q=x/5
r=x%3 #reminder of
s=q**2 #power of
pa=5+2*3+7**2
print(pa)
#for userinput
cc=input('who are you?')
print('abc',cc)
