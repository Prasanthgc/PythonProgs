#newDec
x=1
y=1.0
z=int(x+y)
print(type(z),z,"loosudash")

x=1 #INT
y=1.4 #FLOAT
z=1j #Complex
print(type(x))
print(type(y))
print(type(z))

#Convert Datatypes

#Conv INT to FLOAT
a=float(x)
print(a)
#Conv FLOAT to INT
b=int(y)
print(b)
#ConINT to COmplex
c=complex(x)
print(c)





