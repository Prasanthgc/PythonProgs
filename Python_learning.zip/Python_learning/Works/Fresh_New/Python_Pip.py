
import camelcase
x=camelcase.CamelCase()
y='text to be camelcased'
print(x.hump(y))