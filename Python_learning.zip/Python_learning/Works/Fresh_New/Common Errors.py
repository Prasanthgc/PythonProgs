

#WithNumbers
AA=12
BB=20
#Can have direct arithmetic operations via PRINT
print(AA*BB)
#optional to have extra variable
CC=AA+BB
#print(CC") #Syntax Error
#import XVRModule #ModuleNotFoundError
la={1:"dfdf",2:"fgh"} #Dictionary object
#print(la[3]) #KeyError: 3
lal=[1,2,3]
#print(lal[3]) #IndexError: list index out of range
l=iter([1,2,3])
print(next(l))
print(next(l))
print(next(l))
print(next(l)) #StopIteration
#print("20"+1) #TypeError
#print(int('dgh')) #ValueError
#print(CCC) #NameError
#print(100/0) #ZeroDivisionError
